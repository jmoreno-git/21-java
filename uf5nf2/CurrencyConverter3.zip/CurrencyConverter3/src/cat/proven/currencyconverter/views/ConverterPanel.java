
package cat.proven.currencyconverter.views;

import cat.proven.currencyconverter.controllers.CurrencyConverterController;
import cat.proven.currencyconverter.model.CurrencyConverter;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class ConverterPanel extends JPanel {

    private JTextField tfDollar;
    private JTextField tfEuro;
    private ActionListener listener;
    
    private final CurrencyConverterController controller;

    public ConverterPanel(CurrencyConverterController controller) {
        this.controller = controller;
        listener = controller;
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        JLabel header = new JLabel("Euro-Dollar converter");
        header.setHorizontalAlignment(SwingConstants.CENTER);
        add(header, BorderLayout.NORTH);
        JPanel form = new JPanel();
        form.setLayout(new GridLayout(3, 2));
        tfDollar = new JTextField(20);
        tfEuro = new JTextField(20);
        JLabel lbDollar = new JLabel("dollars");
        JLabel lbEuro = new JLabel("euros");
        JButton btDE = new JButton("Dollar->Euro");
        btDE.setActionCommand("dollar2euro");
        btDE.addActionListener(listener);
        JButton btED = new JButton("Euro->Dollar");
        btED.setActionCommand("euro2dollar");
        btED.addActionListener(listener);
        form.add(tfDollar);   form.add(lbDollar);
        form.add(btDE);   form.add(btED);
        form.add(tfEuro);   form.add(lbEuro);
        add(form, BorderLayout.CENTER);
    }

    public void convertEuroToDollar() {
        String sEuro = tfEuro.getText();
        try {
            double euro = Double.parseDouble(sEuro);
            double dollar = controller.getModel().euroToDollar(euro);
            tfDollar.setText(String.valueOf(dollar));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Bad value");
        }        
    }

    public void convertDollarToEuro() {
        String sDollar = tfDollar.getText();
        try {
            double dollar = Double.parseDouble(sDollar);
            double euro = controller.getModel().dollarToEuro(dollar);
            tfEuro.setText(String.valueOf(euro));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Bad value");
        }
    }
    
}


package cat.proven.currencyconverter;

import cat.proven.currencyconverter.controllers.CurrencyConverterController;
import cat.proven.currencyconverter.views.MainFrame;
import cat.proven.currencyconverter.model.CurrencyConverter;
import javax.swing.SwingUtilities;


public class Main {

    public static void main(String[] args) {
        CurrencyConverter model = new CurrencyConverter();
        CurrencyConverterController controller = 
                new CurrencyConverterController(model);
        SwingUtilities.invokeLater(() -> {
            MainFrame mainFrame = new MainFrame(controller);
            controller.setView(mainFrame);
            mainFrame.setVisible(true);
        });
    }
    
}

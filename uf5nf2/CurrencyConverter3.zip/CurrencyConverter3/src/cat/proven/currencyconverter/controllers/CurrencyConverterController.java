
package cat.proven.currencyconverter.controllers;

import cat.proven.currencyconverter.views.MainFrame;
import cat.proven.currencyconverter.model.CurrencyConverter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JOptionPane;

public class CurrencyConverterController 
        implements WindowListener, ActionListener {

    private MainFrame view;
    private CurrencyConverter model;
    
    public CurrencyConverterController(CurrencyConverter model) {
        this.model = model;
    }

    public CurrencyConverter getModel() {
        return model;
    }

    public void setModel(CurrencyConverter model) {
        this.model = model;
    }

    public MainFrame getView() {
        return view;
    }

    public void setView(MainFrame view) {
        this.view = view;
    }

    @Override
    public void windowOpened(WindowEvent we) {

    }

    @Override
    public void windowClosing(WindowEvent we) {
        exitApp();
    }

    @Override
    public void windowClosed(WindowEvent we) {

    }

    @Override
    public void windowIconified(WindowEvent we) {

    }

    @Override
    public void windowDeiconified(WindowEvent we) {

    }

    @Override
    public void windowActivated(WindowEvent we) {

    }

    @Override
    public void windowDeactivated(WindowEvent we) {

    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        String action = ae.getActionCommand();
        processAction(action);
    }

    private void processAction(String action) {
        switch (action) {
            case "exit":
                exitApp();
                break;
            case "convert":
                view.showConverterPanel();
                break;
            case "about":
                view.showAboutDialog();
                break;
            case "dollar2euro":
                view.getConverterPanel().convertDollarToEuro();
                break;
            case "euro2dollar":
                view.getConverterPanel().convertEuroToDollar();
                break;
        }
    }
    
    private void exitApp() {
        int answer = JOptionPane.showConfirmDialog(view, "Sure to exit?");
        if (answer == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }
    
}

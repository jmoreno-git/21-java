package cat.proven.potatoes;

import cat.proven.potatoes.model.PotatoesModel;
import java.util.Arrays;

public class Tester {

    public static void main(String[] args) {
        PotatoesModel model = new PotatoesModel();
        Double[] weights = new Double[]{3.0, 6.0, 12.0, 25.0, 34.0};
        Arrays.asList(weights).forEach(
                (Double w) -> {
                    System.out.format(
                            "Price of %5.2f kg: %5.2f €/kg\n",
                            w,
                            model.getPrice(w));
                }
        );
    }

}

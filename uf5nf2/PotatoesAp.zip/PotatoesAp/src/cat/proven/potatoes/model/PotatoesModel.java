package cat.proven.potatoes.model;

import java.util.HashMap;
import java.util.Map;

public class PotatoesModel {

    private final Map<Double[], Double> prices;

    public PotatoesModel() {
        prices = new HashMap<>();
        generateTestData();
    }

    public Map<Double[], Double> getPrices() {
        return prices;
    }

    public double getPrice(double weight) {
        double price = -1.0;
        for (Double[] key : prices.keySet()) {
            if ((weight >= key[0]) && (weight < key[1])) {
                price = prices.get(key);
                break;
            }
        }
        return price;
    }

    private void generateTestData() {
        prices.put(new Double[]{0.0, 5.0}, 2.0);
        prices.put(new Double[]{5.0, 10.0}, 1.75);
        prices.put(new Double[]{10.0, 15.0}, 1.5);
        prices.put(new Double[]{15.0, 1000.0}, 1.0);
    }
}

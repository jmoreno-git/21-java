package cat.proven.potatoes;

import cat.proven.potatoes.model.PotatoesModel;
import cat.proven.potatoes.views.MainFrame;
import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {
        PotatoesModel model = new PotatoesModel();
        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setModel(model);
            frame.setVisible(true);
        });
    }
    
}

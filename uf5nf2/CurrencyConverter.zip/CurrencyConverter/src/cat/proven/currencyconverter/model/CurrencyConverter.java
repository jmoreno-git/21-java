package cat.proven.currencyconverter.model;

public class CurrencyConverter {

    private static double ratioDollarEuro = 0.8828; //1 dollar = 0.8828 euros

    public static double dollarToEuro(double amount) {
        return amount * ratioDollarEuro;
    }

    public static double euroToDollar(double amount) {
        return amount / ratioDollarEuro;
    }

}

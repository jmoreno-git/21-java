package cat.proven.store.views;

import cat.proven.store.model.Fridge;
import cat.proven.store.model.Product;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author ProvenSoft
 */
public class FridgeForm implements FormInterface {
    
    @Override
    public Product input() {
        Product p = null;
        Scanner sc = new Scanner(System.in);
        System.out.print("code: ");
        String code = sc.next();
        System.out.print("description: ");
        String description = sc.next();
        try {
            System.out.print("price: ");
            double price = sc.nextDouble();
            System.out.print("stock: ");
            int stock = sc.nextInt();
            System.out.print("capacity: ");
            int capacity = sc.nextInt();
            System.out.print("noFrost: ");
            boolean noFrost = sc.hasNextBoolean();
            p = new Fridge(code, description, price, stock, capacity, noFrost); 
        } catch (InputMismatchException e) {
            p = null;
        }
        return p;
    } 
    
}

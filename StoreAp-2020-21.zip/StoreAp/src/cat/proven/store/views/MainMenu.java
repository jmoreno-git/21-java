
package cat.proven.store.views;

import cat.proven.menu.Menu;
import cat.proven.menu.MenuItem;

/**
 * Main menu for Store application.
 * @author ProvenSoft
 */
public class MainMenu extends Menu {   

    public MainMenu() {
        setTitle("Store app main menu");
        addOption( new MenuItem("Exit", "exit") );
        addOption( new MenuItem("List all products", "listallproducts") );
        addOption( new MenuItem("List product by code", "listproductbycode") );
        addOption( new MenuItem("List products with low stock", "listproductslowstock") );
        addOption( new MenuItem("Add a new product", "addnewproduct") );
        addOption( new MenuItem("Modify product", "modifyproduct") );
        addOption( new MenuItem("Remove product", "removeproduct") );        
    }
    
}

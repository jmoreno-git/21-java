package cat.proven.store.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ProvenSoft
 */
public class Store {

    //attributes.
    private List<Product> products;

    //constructor.
    public Store() {
        products = new ArrayList<>();
    }
    
    public int getNumProducts() {
        return products.size();
    }

    //methods.
    
    /**
     * finds all products in the data source.
     * @return list with all products or null in case of error.
     */
    public List<Product> findAllProducts() {
        return new ArrayList<>(products);
    }

    /**
     * retrieves product with the given code from data source.
     *
     * @param code the code to search.
     * @return product with given code or null in case or error.
     */
    public Product findProductByCode(String code) {
        Product result = null;
        Product p = new Product(code);
        int index = products.indexOf(p);
        if (index >= 0) { //found.
            result = products.get(index);
        } else {
            result = null;
        }
        return result;
    }

    /**
     * retrieves products with stock lower than the given one.
     * @param stock the threshold for the stock
     * @return list of products with low stock,
     * an empty list if none is found or null in case of error.
     */
    public List<Product> findProductsWithLowStock(int stock) {
        List<Product> result = new ArrayList<>();
        for (int i=0; i<products.size(); i++) {
            Product p = products.get(i);
            if (p.getStock()<stock) {
                result.add(p);
            }
        }
        return result;
    }
    
    /**
     * retrieves product at position 'index'
     * @param index the position of the product to be retrieved.
     * @return product at the given position or null in case of error.
     */
    public Product get(int index) {
        Product p = null;
        if ( (index>=0) && (index<products.size()) ) {
            p = products.get(index);
        }
        return p;
    }
    
    /**
     * adds a product to the data source,
     * it avoids adding null objects, or products with null code,
     * or adding when list is full or when code already exists.
     * @param product the product to add.
     * @return true if successful, false otherwise.
     */
    public boolean addProduct(Product product) {
        //TODO: check error conditions.
        boolean b = false;
        if (product != null) {
            if (!products.contains(product)) {
                if (product.getCode() != null) {
                    products.add(product);
                    b = true;
                }
            }
        }
        return b;
    }
    
    /**
     * modifies currentProduct with newProduct.
     * @param currentProduct the product to be modified.
     * @param newProduct the new version of product.
     * @return true if successfully modified, false otherwise.
     */
    public boolean modifyProduct(Product currentProduct, Product newProduct) {
        boolean b = false;
        if ( (currentProduct != null) && (newProduct != null) ) {
            int index = products.indexOf(currentProduct);
            if (index >= 0) { //found.
                if (!products.contains(newProduct)) {
                    products.set(index, newProduct);
                    b = true;
                }
            }
        }
        return b;
    }
    
    /**
     * removes a product from the data source.
     * @param product the product to remove.
     * @return true if successfully removed, false otherwise.
     */
    public boolean removeProduct(Product product) {
        return products.remove(product);
    }
    
    
    /**
     * loads test data into data source.
     * IMPORTANT: remove for production.
     */
    public void loadInitialTestData() {
        addProduct( new Product("C01", "Desc01", 101.0, 11) );
        addProduct( new Product("C02", "Desc02", 102.0, 12) );
        addProduct( new Tv("C03", "Desc03", 103.0, 13, 50) );
        addProduct( new Product("C04", "Desc04", 104.0, 14) );
        addProduct( new Fridge("C05", "Desc05", 105.0, 15, 150, true) );
        addProduct( new Product("C06", "Desc06", 106.0, 16) );
    }
    
}

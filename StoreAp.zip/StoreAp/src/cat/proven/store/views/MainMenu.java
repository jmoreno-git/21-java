
package cat.proven.store.views;

import cat.proven.menu.Menu;
import cat.proven.menu.MenuItem;

/**
 * Main menu for Store application.
 * @author ProvenSoft
 */
public class MainMenu extends Menu {   

    public MainMenu() {
        setTitle("Store app main menu");
        addOption( new MenuItem("Exit", "exit") );
        addOption( new MenuItem("List all products", "products/listall") );
        addOption( new MenuItem("List product by code", "product/listbycode") );
        addOption( new MenuItem("List products with low stock", "product/listbylowstock") );
        addOption( new MenuItem("Add a new product", "product/add") );
        addOption( new MenuItem("Modify product", "product/modify") );
        addOption( new MenuItem("Remove product", "product/remove") );        
    }
    
}

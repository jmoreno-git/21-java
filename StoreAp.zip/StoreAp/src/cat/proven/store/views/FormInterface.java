package cat.proven.store.views;

import cat.proven.store.model.Product;

/**
 *
 * @author ProvenSoft
 */
public interface FormInterface {
    /**
     * reads data for a product from the user.
     * @return product with entered data or null in case of error.
     */
    public Product input();
}

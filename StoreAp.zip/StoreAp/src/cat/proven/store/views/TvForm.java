package cat.proven.store.views;

import cat.proven.store.model.Product;
import cat.proven.store.model.Tv;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author ProvenSoft
 */
public class TvForm implements FormInterface {

    @Override
    public Product input() {
        Product p = null;
        Scanner sc = new Scanner(System.in);
        System.out.print("code: ");
        String code = sc.next();
        System.out.print("description: ");
        String description = sc.next();
        try {
            System.out.print("price: ");
            double price = sc.nextDouble();
            System.out.print("stock: ");
            int stock = sc.nextInt();
            System.out.print("inches: ");
            int inches = sc.nextInt();
            p = new Tv(code, description, price, stock, inches); 
        } catch (InputMismatchException e) {
            p = null;
        }
        return p;
    }
    
}

package cat.proven.store;

import cat.proven.menu.Menu;
import cat.proven.store.model.Product;
import cat.proven.store.model.Store;
import cat.proven.store.views.FormInterface;
import cat.proven.store.views.FridgeForm;
import cat.proven.store.views.MainMenu;
import cat.proven.store.views.ProductForm;
import cat.proven.store.views.TvForm;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author ProvenSoft
 */
public class Main {

    /**
     * model
     */
    private Store myStore;

    /**
     * main menu
     */
    private Menu mainMenu;

    /**
     * flag to exit application
     */
    private boolean exit;
    
    public static void main(String[] args) {
        Main myApp = new Main();
        myApp.run();
    }

    private void run() {
        exit = false; //flag to exit application.
        //instantiate data holder (model).
        myStore = new Store();
        //load initial test data. Remove for production.
        myStore.loadInitialTestData();
        //instantiate main menu.
        mainMenu = new MainMenu();
        //intaraction and control loop.
        doInteract();
        System.out.println("Goodbye!");
    }

    /**
     * performs interaction with user (view)
     */
    public void doInteract() {
        do {  //loop to interact with user until they chooses exit application.
            //show menu.
            mainMenu.show();
            //read user's choice.
            String action = mainMenu.getSelectedOptionActionCommand();
            doAction(action);
            //System.out.println("You selected option: "+selectedOption); 
        } while (!exit);        
    }
    
    /**
     * executes response to user's actions (control)
     * @param action the action to execute
     */
    public void doAction(String action) {
        if (action == null) {
            action = "wrongoption";
        }
        switch (action) {
            case "exit": //exit.
                exit = true;
                break;
            case "products/listall": //list all products
                listAllProducts();
                break;
            case "product/listbycode": //list product by code
                listProductByCode();
                break;
            case "product/listbylowstock": //list products with low stock
                listProductsWithLowStock();
                break;
            case "product/add": //add a new product
                addNewProduct();
                break;
            case "product/modify": //modify a product
                modifyProduct();
                break;
            case "product/remove": //remove a product
                removeProduct();
                break;
            default:
                System.out.println("Invalid option!");
                break;
        }        
    }
    
    
    /**
     * ********* VIEW METHODS **********
     */

    /**
     * displays list of objects
     * @param data the list of objects to display
     */
    private void displayProductList(List<Product> data) {
        if (data == null) {
            System.out.println("Null data!");
        } else {
            for (int i = 0; i < data.size(); i++) {
                Product p = data.get(i);
                System.out.println(p.toString());
            }
            System.out.format("%d products found\n", data.size());
        }
    }

    /**
     * displays a message to user
     * @param message the message to display
     */
    public void alert(String message) {
        System.out.println(message);
    }
    
    /**
     * displays a message to user and reads an answer
     * @param message the message to display to user
     * @return user's answer or null in case of error
     */
    public String inputString(String message) {
        System.out.print(message);
        Scanner sc = new Scanner(System.in);
        return sc.next();
    }

    /**
     * displays a message to user and reads a confirmation answer
     * @param message the message to display to user
     * @return user's answer or false in case of error
     */
    public boolean confirm(String message) {
        boolean result = false;
        System.out.print(message);
        Scanner sc = new Scanner(System.in);
        try {
            result = sc.nextBoolean();
        } catch (InputMismatchException e) {
            result = false;
        }
        return result;
    }

    /**
     * displays a product
     * @param product the product to display
     */
    public void displayProduct(Product product) {
        if (product == null) {
            System.out.println("Null data");
        } else {
            System.out.println(product.toString());
        }
    }

    /**
     * reads data from the user for a product
     * @param type the type of product to read
     * @return product read from user or null in case of error
     */
    public Product inputProduct(String type) {
        Product p = null;
        FormInterface form = null;
        if (type != null) {
            switch (type) {
                case "Product":
                    form = new ProductForm();
                    break;
                case "Tv":
                    form = new TvForm();
                    break;
                case "Fridge":
                    form = new FridgeForm();
                    break;
                default:
                    form = new ProductForm();
                    break;
            }
            p = form.input();
        }
        return p;
    }

    /**
     * ********* CONTROL METHODS **********
     */
    
    /**
     * displays all products retrieves the list of all products, in case of
     * errors, reports the error to user, if successful, shows list to user
     */
    public void listAllProducts() {
        //retrieve data.
        List<Product> result = myStore.findAllProducts();
        //display data.
        if (result == null) {
            alert("Error accessing data");
        } else {
            displayProductList(result);
        }
    }

    /**
     * asks the code to user, if error reading code, report that to user, if
     * not, searches a product with that code, if found, displays product to
     * user, if not report error to user
     */
    public void listProductByCode() {
        //read the code.
        String code = inputString("Input the code: ");
        if (code == null) {
            alert("Error reading the code");
        } else {
            Product result = myStore.findProductByCode(code);
            if (result == null) {  //not found.
                alert("Product not found");
            } else {
                displayProduct(result);
            }
        }
    }

    /**
     * asks the user the type of the product, asks the user to input data for
     * the new product, if not correctly read, report that to user, if correctly
     * read, adds the new product to data source, and reports result to user
     */
    public void addNewProduct() {
        String type = inputString("Type: ");
        if (type != null) {
            //read product from user.
            Product newProduct = inputProduct(type);
            if (newProduct == null) {
                alert("Error reading product");
            } else {
                //add the new product to data source.
                boolean result = myStore.addProduct(newProduct);
                //report result to user.
                if (result) {
                    alert("Product successfully added");
                } else {
                    alert("Error adding product");
                }
            }
        } else {
            alert("Error reading type");
        }

    }

    /**
     * asks the user the min. stock, searches products with stock lower than the
     * given one, displays result to user (data or error condition)
     */
    private void listProductsWithLowStock() {
        //read threshold stock from user.
        String sstock = inputString("Input stock: ");
        if (sstock == null) {
            alert("Error reading stock");
        } else {
            try {
                int stock = Integer.parseInt(sstock);
                List<Product> result = myStore.findProductsWithLowStock(stock);
                if (result == null) {
                    alert("Error retrieving data");
                } else {
                    displayProductList(result);
                }
            } catch (NumberFormatException e) {
                alert("Bad value for stock");
            }
        }
    }

    /**
     * asks the code of the product to modify, if error reading code, report
     * error to user, if code successfully read, searches the product with that
     * code, if not found o error, report to user, if found, shows product to
     * user and asks for confirmation, if user confirms, reads from user new
     * data for the product, if error reading product, report to user, if
     * successfully read, modifies in the data source, and report result to
     * user
     */
    private void modifyProduct() {
        String code = inputString("code: ");
        if (code == null) {
            alert("Error reading code");
        } else {
            Product found = myStore.findProductByCode(code);
            if (found != null) {
                displayProduct(found);
                if (!confirm("Are you sure? (true/false):  ")) {
                    alert("Operation cancelled by user");
                } else {
                    Class c = found.getClass();
                    String type = c.getSimpleName();
                    //read product from user.
                    if (type != null) {
                        Product newProduct = inputProduct(type);
                        //modify current version with new version of product.
                        boolean result = myStore.modifyProduct(found, newProduct);
                        if (result) {
                            alert("Product successfully modified");
                        } else {
                            alert("Error modifying product");
                        }
                    }
                }                
            } else {
                alert("Product not found");
            }
        }
    }

    /**
     * asks the code of the product to remove, if error reading code, report
     * error to user, if code successfully read, searches the product with that
     * code, if not found o error, report to user, if found, shows product to
     * user and asks for confirmation, if user confirms, it attemps to remove it
     * and report result to user
     */
    private void removeProduct() {
        String code = inputString("code: ");
        if (code == null) {
            alert("Error reading code");
        } else {
            Product found = myStore.findProductByCode(code);
            if (found != null) {
                displayProduct(found);
                if (!confirm("Are you sure? (true/false):  ")) {
                    alert("Operation cancelled by user");
                } else {
                    boolean result = myStore.removeProduct(found);
                    if (result) {
                        alert("Product successfully removed");
                    } else {
                        alert("Error removing product");
                    }
                }                
            } else {
                alert("Product not found");
            }
        }
    }

}

package cat.proven.employeefilepersist;

/**
 *
 * @author ProvenSoft
 */
public class WriteCsv {
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}

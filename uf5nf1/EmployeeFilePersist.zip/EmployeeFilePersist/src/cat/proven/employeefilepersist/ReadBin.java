
package cat.proven.employeefilepersist;

import cat.proven.employeefilepersist.model.Employee;
import cat.proven.employeefilepersist.model.persist.EmployeeBinFilePersist;
import cat.proven.employeefilepersist.model.persist.FilePersistInterface;
import cat.proven.employeefilepersist.model.persist.PersistInterface;
import java.util.List;

/**
 *
 * @author ProvenSoft
 */
public class ReadBin {

    public static void main(String[] args) {
        String filename = "mystaff.txt"; //TODO read this from arguments
        //TODO treat all errors.
        FilePersistInterface persister = new EmployeeBinFilePersist();
        List<Employee> data = persister.readList(filename);
        System.out.format("%d employees read\n", data.size());
        printList(data);
    }
    
    private static void printList(List<? extends Object> lst) {
        lst.forEach(e -> {
            System.out.println(e.toString());
        });
    }
} 

package cat.proven.employeefilepersist.model.persist;

import java.util.List;

/**
 *
 * @author ProvenSoft
 * @param <T> the base type
 */
public interface PersistInterface<T> {
    /**
     * writes a list to a file
     * @param filename the path to file to write list
     * @param data the list to write to file
     * @return number of elements written
     */
    public int writeList(String filename, List<T> data);
    /**
     * reads a list from a file
     * @param filename the path to file to read from
     * @return list with read data
     */
    public List<T> readList(String filename);
}

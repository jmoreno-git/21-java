package cat.proven.employeefilepersist.model.persist;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * File persistence interface for lists of elements of any serializable type T
 * @author ProvenSoft
 * @param <T> the base type
 */
public interface FilePersistInterface<T> {
    /**
     * writes a list to a file
     * default implementation with objects
     * @param filename the path to file to write list
     * @param data the list to write to file
     * @return number of elements written
     */
    public default int writeList(String filename, List<T> data) {
        int counter = 0;
        try (ObjectOutputStream s = new ObjectOutputStream(new FileOutputStream(filename))) {
            for (T elem: data) {
                s.writeObject(elem);
                counter++;
            }
        } catch (IOException e) {
            //TODO
        }
        return counter;        
    }
    /**
     * reads a list from a file
     * default implementation with objects
     * @param filename the path to file to read from
     * @return list with read data
     */
    public default List<T> readList(String filename) {
       List<T> data = new ArrayList<>();
        try (ObjectInputStream s = new ObjectInputStream(new FileInputStream(filename))) {
            do {
                T e = (T) s.readObject();
                if (e != null) data.add(e);
            } while (true);
        } catch (FileNotFoundException e) {
            //TODO 
        } catch (EOFException e) {
            //TODO 
        } catch (IOException e) {
            //TODO
        } catch (ClassNotFoundException ex) {        
            //TODO
        }
        return data;        
    }
}

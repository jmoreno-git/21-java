package cat.proven.employeefilepersist.model.persist;

import cat.proven.employeefilepersist.model.Address;
import cat.proven.employeefilepersist.model.Employee;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

/**
 * File persistence implementationn for lists of employees in CSV format
 * @author ProvenSoft
 */
public class EmployeeCsvFilePersist implements FilePersistInterface<Employee> {

    /**
     * delimiter to be used in csv format
     */
    private String delimiter = ";";

    /**
     * get delimiter
     * @return delimiter
     */
    public String getDelimiter() {
        return delimiter;
    }

    /**
     * set delimiter
     * @param delimiter new value for delimiter
     */
    public void setDelimiter(String delimiter) {
        this.delimiter = delimiter;
    }

    /**
     * writes a list of employees to a file in binary format
     */
    @Override
    public int writeList(String filename, List<Employee> data) {
        int counter = 0;
        try (PrintWriter dos = new PrintWriter(filename)) {
            for (Employee elem : data) {
                writeEmployee(dos, elem);
                counter++;
            }
        } catch (IOException e) {
            //TODO
        }
        return counter;
    }

    /**
     * reads a list of employees from a file in binary format
     */
    @Override
    public List<Employee> readList(String filename) {
        List<Employee> data = new ArrayList<>();
        try (BufferedReader dis = new BufferedReader(new FileReader(filename))) {
            do {
                Employee e = readEmployee(dis);
                if (e != null) {
                    data.add(e);
                } else {
                    break;
                }
            } while (true);
        } catch (FileNotFoundException e) {
            //TODO 
        } catch (EOFException e) {
            //TODO 
        } catch (IOException e) {
            //TODO
        }
        return data;
    }

    /**
     * writes an employee to a PrintWriter
     * @param ds PrintWriter to write to
     * @param e employee to write
     * @throws IOException in case of input output error
     */
    private void writeEmployee(PrintWriter ds, Employee e) throws IOException {
        String csv = employeeToCsv(e);
        ds.println(csv);
    }

    /**
     * converts employee to a csv format
     * @param e employee to convert
     * @return string csv representation
     */
    private String employeeToCsv(Employee e) {
        StringBuilder sb = new StringBuilder();
        sb.append(e.getPhone());
        sb.append(delimiter);
        sb.append(e.getName());
        sb.append(delimiter);
        sb.append(e.getAge());
        sb.append(delimiter);
        sb.append(e.isSenior());
        sb.append(delimiter);
        sb.append(e.getSalary());
        sb.append(delimiter);
        sb.append(addressToCsv(e.getAddress()));
        return sb.toString();
    }

    /**
     * converts address to a csv format
     * @param a address to convert
     * @return string csv representation
     */    
    private String addressToCsv(Address a) {
        StringBuilder sb = new StringBuilder();
        sb.append(a.getStreetName());
        sb.append(delimiter);
        sb.append(a.getStreetNumber());
        sb.append(delimiter);
        sb.append(a.getZipCode());
        return sb.toString();
    }

    /**
     * reads an employee from a BufferedReader
     * @param ds BufferedReader to read from
     * @return employee read
     * @throws IOException in case of input output error
     */
    private Employee readEmployee(BufferedReader ds) throws IOException {
        Employee elem = null;
        String line = ds.readLine();
        if ((line != null) && (line.length() > 0)) {
            StringTokenizer st = new StringTokenizer(line, delimiter, false);
            while (st.hasMoreTokens()) {
                try {
                    String phone = st.nextToken();
                    String name = st.nextToken();
                    int age = Integer.parseInt(st.nextToken());
                    boolean senior = Boolean.parseBoolean(st.nextToken());
                    double salary = Double.parseDouble(st.nextToken());
                    Address address = readAddress(st);
                    elem = new Employee(phone, name, age, senior, salary, address);
                } catch (NoSuchElementException e) { //no more tokens
                    //TODO
                } catch (NumberFormatException e) { //data conversion error
                    //TODO
                }
            }
        }
        return elem;
    }

    /**
     * reads an address from StringTokenizer
     * @param st StringTokenizer to get token from
     * @return address read
     * @throws NoSuchElementException if there are not enough tokens to read all fields
     * @throws NumberFormatException if any token has not the proper format
     */
    private Address readAddress(StringTokenizer st) throws NoSuchElementException, NumberFormatException {
        String street = st.nextToken();
        int age = Integer.parseInt(st.nextToken());
        String zip = st.nextToken();
        return new Address(street, age, zip);
    }

}

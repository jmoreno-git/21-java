/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.employeefilepersist.model.persist;

import cat.proven.employeefilepersist.model.Address;
import cat.proven.employeefilepersist.model.Employee;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alumne
 */
public class EmployeeBinFilePersist implements PersistInterface<Employee> {

    @Override
    public int writeList(String filename, List<Employee> data) {
        int counter = 0;
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(filename))) {
            for (Employee elem: data) {
                writeEmployee(dos, elem);
                counter++;
            }
        } catch (EOFException e) {
            //TODO 
        } catch (IOException e) {
            //TODO
        }
        return counter;
    }

    @Override
    public List<Employee> readList(String filename) {
        List<Employee> data = new ArrayList<>();
        try (DataInputStream dis = new DataInputStream(new FileInputStream(filename))) {
            do {
                Employee e = readEmployee(dis);
                data.add(e);
            } while (true);
        } catch (EOFException e) {
            //TODO 
        } catch (IOException e) {
            //TODO
        }        
        return data;
    }

    private void writeEmployee(DataOutputStream ds, Employee e) throws IOException {
        ds.writeUTF(e.getPhone());
        ds.writeUTF(e.getName());
        ds.writeInt(e.getAge());
        ds.writeBoolean(e.isSenior());
        ds.writeDouble(e.getSalary());
        writeAddress(ds, e.getAddress());
    }

    private void writeAddress(DataOutputStream ds, Address a) throws IOException {
        ds.writeUTF(a.getStreetName());
        ds.writeInt(a.getStreetNumber());
        ds.writeUTF(a.getZipCode());
    }

    private Employee readEmployee(DataInputStream ds) throws IOException {
        String phone = ds.readUTF();
        String name = ds.readUTF();
        int age = ds.readInt();
        boolean senior = ds.readBoolean();
        double salary = ds.readDouble();
        Address address = readAddress(ds);
        return new Employee(phone, name, age, senior, salary, address);
    }

    private Address readAddress(DataInputStream ds) throws IOException {
        String street = ds.readUTF();
        int number = ds.readInt();
        String zip = ds.readUTF();
        return new Address(street, number, zip);
    }
    
}

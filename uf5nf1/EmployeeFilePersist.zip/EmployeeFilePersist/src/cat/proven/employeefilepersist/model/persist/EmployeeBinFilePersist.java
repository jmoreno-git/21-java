
package cat.proven.employeefilepersist.model.persist;

import cat.proven.employeefilepersist.model.Address;
import cat.proven.employeefilepersist.model.Employee;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * File persistence implementationn for lists of employees in binary format
 * @author ProvenSoft
 */
public class EmployeeBinFilePersist implements FilePersistInterface<Employee> {

    /**
     * writes a list of employees to a file in binary format
     */
    @Override
    public int writeList(String filename, List<Employee> data) {
        int counter = 0;
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(filename))) {
            for (Employee elem: data) {
                writeEmployee(dos, elem);
                counter++;
            }
        } catch (IOException e) {
            //TODO
        }
        return counter;
    }

    /**
     * reads a list of employees from a file in binary format
     */
    @Override
    public List<Employee> readList(String filename) {
        List<Employee> data = new ArrayList<>();
        try (DataInputStream dis = new DataInputStream(new FileInputStream(filename))) {
            do {
                Employee e = readEmployee(dis);
                if (e != null) data.add(e);
            } while (true);
        } catch (FileNotFoundException e) {
            //TODO 
        } catch (EOFException e) {
            //TODO 
        } catch (IOException e) {
            //TODO
        }       
        return data;
    }

    /**
     * writes an employee to a DataOutputStream
     * @param ds DataOutputStream to write to
     * @param e employee to write
     * @throws IOException in case of input output error
     */
    private void writeEmployee(DataOutputStream ds, Employee e) throws IOException {
        ds.writeUTF(e.getPhone());
        ds.writeUTF(e.getName());
        ds.writeInt(e.getAge());
        ds.writeBoolean(e.isSenior());
        ds.writeDouble(e.getSalary());
        writeAddress(ds, e.getAddress());
    }

    /**
     * writes an address to a DataOutputStream
     * @param ds DataOutputStream to write to
     * @param a address to write
     * @throws IOException in case of input output error
     */
    private void writeAddress(DataOutputStream ds, Address a) throws IOException {
        ds.writeUTF(a.getStreetName());
        ds.writeInt(a.getStreetNumber());
        ds.writeUTF(a.getZipCode());
    }

    /**
     * reads an employee from a DataInputStream
     * @param ds DataInputStream to read from
     * @return employee read
     * @throws IOException in case of input output error
     */
    private Employee readEmployee(DataInputStream ds) throws IOException {
        Employee elem = null;
        String phone = ds.readUTF();
        String name = ds.readUTF();
        int age = ds.readInt();
        boolean senior = ds.readBoolean();
        double salary = ds.readDouble();
        Address address = readAddress(ds);
        elem = new Employee(phone, name, age, senior, salary, address);
        return elem;
    }

    /**
     * reads an address from DataInputStream
     * @param ds DataInputStream to read from
     * @return address read
     * @throws IOException in case of input output error
     */
    private Address readAddress(DataInputStream ds) throws IOException {
        String street = ds.readUTF();
        int number = ds.readInt();
        String zip = ds.readUTF();
        return new Address(street, number, zip);
    }
    
}

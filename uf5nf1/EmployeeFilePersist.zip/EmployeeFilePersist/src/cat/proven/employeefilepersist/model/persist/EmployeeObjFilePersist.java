
package cat.proven.employeefilepersist.model.persist;

import cat.proven.employeefilepersist.model.Employee;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ProvenSoft
 */
public class EmployeeObjFilePersist implements FilePersistInterface<Employee> {
//
//    @Override
//    public int writeList(String filename, List<Employee> data) {
//        int counter = 0;
//        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
//            for (Employee elem: data) {
//                oos.writeObject(elem);
//                counter++;
//            }
//        } catch (IOException e) {
//            //TODO
//        }
//        return counter;
//    }
//
//    @Override
//    public List<Employee> readList(String filename) {
//        List<Employee> data = new ArrayList<>();
//        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
//            do {
//                Employee e = (Employee) ois.readObject();
//                data.add(e);
//            } while (true);
//        } catch (FileNotFoundException e) {
//            //TODO 
//        } catch (EOFException e) {
//            //TODO 
//        } catch (IOException e) {
//            //TODO
//        } catch (ClassNotFoundException ex) {        
//            Logger.getLogger(EmployeeObjFilePersist.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return data;
//    }

    
}

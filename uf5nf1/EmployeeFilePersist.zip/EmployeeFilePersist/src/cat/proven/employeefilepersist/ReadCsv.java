
package cat.proven.employeefilepersist;

/**
 *
 * @author ProvenSoft
 */
public class ReadCsv {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}

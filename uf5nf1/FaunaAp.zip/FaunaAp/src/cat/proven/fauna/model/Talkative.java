package cat.proven.fauna.model;

/**
 * Interface to make objects talk.
 * @author ProvenSoft
 */
public interface Talkative {
    public void talk();
}

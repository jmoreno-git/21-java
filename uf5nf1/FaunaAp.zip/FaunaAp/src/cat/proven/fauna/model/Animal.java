package cat.proven.fauna.model;

import java.util.Objects;

/**
 *
 * @author ProvenSoft
 */
public abstract class Animal implements Talkative {
    
    private String name;
    private double weight;

    public Animal(String name, double weight) {
        this.name = name;
        this.weight = weight;
    }
   
    public Animal() {
    }
    
    public Animal(String name) {
        this.name = name;
    }

    public Animal(Animal other) {
        this.name = other.name;
        this.weight = other.weight;
    }    
    
    //Geters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 89 * hash + Objects.hashCode(this.name);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Animal other = (Animal) obj;
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Animal{name=").append(name);
        sb.append(", weight=").append(weight);
        sb.append('}');
        return sb.toString();
    }
   
}

package cat.proven.fauna.model;

/**
 * ADT for Cat
 * @author ProvenSoft
 */
public class Cat extends Animal {

    public Cat(String name, double weight) {
        super(name, weight);
    }

    public Cat() {
    }

    public Cat(String name) {
        super(name);
    }
    
    public Cat(Cat other) {
        super(other);
    }

    @Override
    public void talk() {
        System.out.println("Meu!");
    }
        
}

package cat.proven.fauna.model;

/**
 *
 * @author ProvenSoft
 */
public class Dog extends Animal {
    public static int numlegs;
    private boolean dangerous;

    public Dog(String name, double weight, boolean dangerous) {
        super(name, weight);
        this.dangerous = dangerous;
        numlegs = 4;
    }

    public Dog() {
    }

    public Dog(String name) {
        super(name);
    }
    
    public Dog(Dog other) {
        super(other);
        this.dangerous = other.dangerous;
    }
    
    public boolean isDangerous() {
        return dangerous;
    }

    public void setDangerous(boolean dangerous) {
        this.dangerous = dangerous;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Dog{").append(super.toString());
        sb.append("; dangerous=").append(dangerous);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public void talk() {
        System.out.println("Wow!");
    }
    
    
}

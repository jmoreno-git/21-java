package cat.proven.fauna;

import cat.proven.fauna.model.Dog;
import cat.proven.fauna.model.Cat;
import cat.proven.fauna.model.Animal;
import cat.proven.fauna.model.Talkative;
import java.util.Scanner;

/**
 *
 * @author ProvenSoft
 */
public class FaunaAp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Instantiate a new Cat
//        Cat myCat = new Cat();
//        //Set values
//        myCat.setName("Garfield");
//        myCat.setWeight(8.5);
//        
//        System.out.println(myCat.toString());
//         //Instantiate another Cat
//        Cat otherCat = new Cat("Felix",4);
//        System.out.println(otherCat.toString());
//        
//        
//        Cat[] cats = new Cat[10];
//        cats[0] = myCat;
//        cats[1] = otherCat;
//        cats[2] = myCat;
//        //Printing the array
//        System.out.println("Print cats arary");
//        for(int i = 0; i<cats.length; i++){
//            if(cats[i] != null) {
//                System.out.println(cats[i].toString());
//            }
//        }
//        
        
//        Dog myDog1 = new Dog("Bobby", 10.0, false);
//        Dog myDog2 = new Dog("Bobby", 10.0, false);
//        System.out.println("myDog1==myDog2: "+(myDog1==myDog2));
//        if (myDog1.equals(myDog2)) {
//            System.out.println("Dogs are equal");
//        } else {
//            System.out.println("Dogs are different");
//        }
//        System.out.println("myDog1:"+myDog1.toString());
                
        //create an array of Animal
        Talkative [] animals = new Talkative[5];
        animals[0] = new Dog("Bobby", 10.0, false);
        animals[1] = new Cat("Marilynn", 8.0);
        animals[2] = new Dog("Lucy", 15.0, true);
        animals[3] = new Cat("Garfield", 30);
        animals[4] = new Dog("Lucas", 12, false);
        
        //display animals.
        for (int i=0; i<animals.length; i++) {
            System.out.println(animals[i].toString());
        }
        
//        makeItTalk(animals[2]);
//        makeItTalk(animals[3]);
//        makeThemTalk(animals);
        System.out.format("Dogs have %d legs\n", Dog.numlegs);
        Dog d = new Dog("Milú", 5, false);
        Dog d2 = new Dog("Leia", 2, true);
        System.out.format("Milú has %d legs\n", d.numlegs);
        d.numlegs = 3;
        System.out.format("Dogs have %d legs\n", Dog.numlegs);
        System.out.format("Leia has %d legs\n", d2.numlegs);
        
        //Ask the user which animal to print.
        System.out.print("Select animal index: ");
        Scanner scan = new Scanner(System.in);
        int index = scan.nextInt();
        if ((index>=0) && (index<animals.length)) {
            System.out.format("Animal at position %d is %s\n",
                index, animals[index]);            
        } else {
            System.out.println("Invalid index");
        }
        
    }
    
    /**
     * makes talk the talkative t
     * @param t the talkative to talk
     */
    public static void makeItTalk(Talkative t) {
        t.talk();
    }
    
    /**
     * makes talk a list of talkatives.
     * @param talkatives the collection of talkatives to make talk.
     */
    public static void makeThemTalk(Talkative [] talkatives) {
        for (Talkative t: talkatives) {
            t.talk();
        }
    }
    
}

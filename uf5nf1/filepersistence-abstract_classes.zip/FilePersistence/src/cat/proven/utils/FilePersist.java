package cat.proven.utils;

import java.util.List;

/**
 * abstract class to persist a list of objects of type T in a file.
 * @author Jose Moreno
 * @param <T> the type of entity of the list.
 */
public abstract class FilePersist<T> {
    /**
     * the path to the file where persistence of data is to be made.
     */
    private String filename;

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }
    
    /**
     * saves a list of data of type T into a file.
     * @param data the data to be saved.
     * @return number of entities saved.
     */
    public abstract int save(List<T> data);
    
    /**
     * reads a list of entities of type T from a file.
     * @return a list with all the data read or null in case of error.
     */
    public abstract List<T> load();
}

package cat.proven.utils;

import java.io.BufferedReader;
import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * class to persist a list of objects of type T in a file with CSV format.
 * @author Jose Moreno
 * @param <T> the type of object in the list.
 */
public abstract class CsvFilePersist<T> extends FilePersist<T> {
    
    /**
     * the delimiter used to separate fields.
     */
    private String delimiter;

    public String getDelimiter() {
        return delimiter;
    }

    public void setDelimiter(String delimiter) {
        this.delimiter = delimiter;
    }
    
    @Override
    public int save(List<T> data) {
        int counter = 0;
        File file = new File(getFilename());
        try (PrintWriter pw = new PrintWriter(file)) {
            for (T e : data) {
                writeObjectToStream(e, pw);
                counter++;
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
        }
        return counter;
    }

    @Override
    public List<T> load() {
        File file = new File(getFilename());
        List<T> data = null;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            data = new ArrayList<>();
            try {
                while (true) {
                    //while end of file.
                    T e = readObjectFromStream(br);
                    if (e != null) {
                        data.add(e);
                    }
                } 
            } catch (EOFException ex) {
                //reached end of file.
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
        }
        return data;
    }

    /**
     * writes an object to stream.
     * @param e the object to write.
     * @param pw the stream to write to.
     * @throws IOException in case of IO exception.
     */
    protected abstract void writeObjectToStream(T e, PrintWriter pw) 
        throws IOException;    
    
    /**
     * reads an object from stream.
     * @param br the DataInputStream to read from.
     * @return object with the data read.
     * @throws IOException in case of IO exception
     * @throws EOFException in case of end of file reached.
     */
    protected abstract T readObjectFromStream(BufferedReader br) 
            throws IOException, EOFException;
    
}

package cat.proven.utils;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Class to persist a list of objects of T type in a file with DataIOStream.
 * @author Jose Moreno
 * @param <T> the type of objects in list.
 */
public abstract class DataStreamFilePersist<T> extends FilePersist<T> {

    @Override
    public int save(List<T> data) {
        int counter = 0;
        File file = new File(getFilename());
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(file))) {
            for (T e : data) {
                writeObjectToStream(e, dos);
                counter++;
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
        }
        return counter;
    }

    @Override
    public List<T> load() {
        File file = new File(getFilename());
        List<T> data = null;
        try (DataInputStream dos = new DataInputStream(new FileInputStream(file))) {
            data = new ArrayList<>();
            try {
                while (true) {  //while end of file.
                    T e = readObjectFromStream(dos);
                    if (e != null) {
                        data.add(e);
                    }
                }
            } catch (EOFException ex) {
                //reached end of file.
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
        }
        return data;
    }

    /**
     * writes an object to stream.
     * @param e the object to write.
     * @param dos the stream to write to.
     * @throws IOException in case of IO exception.
     */
    protected abstract void writeObjectToStream(T e, DataOutputStream dos) 
            throws IOException;   
    
    /**
     * reads an object from stream.
     * @param dis the DataInputStream to read from.
     * @return object with the data read.
     * @throws IOException in case of IO exception
     * @throws EOFException in case of end of file reached.
     */
    protected abstract T readObjectFromStream(DataInputStream dis) 
            throws IOException, EOFException;

}

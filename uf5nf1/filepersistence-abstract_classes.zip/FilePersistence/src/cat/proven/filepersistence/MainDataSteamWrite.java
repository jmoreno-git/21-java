package cat.proven.filepersistence;

import cat.proven.filepersistence.model.Employee;
import cat.proven.filepersistence.model.persist.EmployeeDataStreamFilePersist;
import java.util.ArrayList;
import java.util.List;
import cat.proven.utils.FilePersist;

/**
 *
 * @author ProvenSoft
 */
public class MainDataSteamWrite {

    public static void main(String[] args) {
        String pathToFile = "employee_ds.txt";
        //create test data.
        List<Employee> staff = initTestData();
        //instantiate persistence helper.
        FilePersist<Employee> helper = new EmployeeDataStreamFilePersist();
        //set filename.
        helper.setFilename(pathToFile);
        //save data to file.
        int result = helper.save(staff);
        //show result to user.
        System.out.println("Number of employees saved: "+result);
    }

    private static List<Employee> initTestData() {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("111", "name111", 11));
        employees.add(new Employee("112", "name112", 12));
        employees.add(new Employee("113", "name113", 13));
        employees.add(new Employee("114", "name114", 14));
        employees.add(new Employee("115", "name115", 15));
        return employees;
    }
    
}

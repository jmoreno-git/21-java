package cat.proven.filepersistence.model.persist;

import cat.proven.filepersistence.model.Employee;
import cat.proven.utils.CsvFilePersist;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * class to persist a list of employee in a file with CSV format.
 * @author ProvenSoft
 */
public class EmployeeCsvFilePersist extends CsvFilePersist<Employee> {

    @Override
    protected void writeObjectToStream(Employee e, PrintWriter pw) 
            throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append(e.getPhone())
          .append(getDelimiter())
          .append(e.getName())
          .append(getDelimiter())
          .append(String.valueOf(e.getAge()));
        pw.println(sb.toString());
    }

    @Override
    protected Employee readObjectFromStream(BufferedReader br) 
            throws IOException, EOFException {
        Employee emp = null;
        String line = br.readLine();
        if (line == null) 
            throw new EOFException("End of file reached with readline()");
        Scanner sc = new Scanner(line).useDelimiter(getDelimiter());
        try {
            String phone = sc.next();
            String name = sc.next();
            int age = sc.nextInt();
            emp = new Employee(phone, name, age);
        } catch (InputMismatchException ex) {
            emp = null;   
        }
        return emp;   
    }
    
}

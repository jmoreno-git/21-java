package cat.proven.filepersistence.model;

/**
 *
 * @author ProvenSoft
 */
public class Address {
    
}

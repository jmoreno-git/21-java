package cat.proven.filepersistence.model.persist;

import cat.proven.filepersistence.model.Employee;
import cat.proven.utils.DataStreamFilePersist;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;

/**
 * Class to persist a list of employees in a file with DataIOStream.
 * @author ProvenSoft
 */
public class EmployeeDataStreamFilePersist extends DataStreamFilePersist<Employee> {
    
    @Override
    protected Employee readObjectFromStream(DataInputStream dis) 
            throws IOException, EOFException {
        Employee e;
        String phone = dis.readUTF();
        String name = dis.readUTF();
        int age = dis.readInt();
        e = new Employee(phone, name, age);
        return e;
    }

    @Override
    protected void writeObjectToStream(Employee e, DataOutputStream dos) 
            throws IOException {
        dos.writeUTF(e.getPhone());
        dos.writeUTF(e.getName());
        dos.writeInt(e.getAge());
    }

}

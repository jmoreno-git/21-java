package cat.proven.filepersistence;

import cat.proven.filepersistence.model.Employee;
import cat.proven.filepersistence.model.persist.EmployeeCsvFilePersist;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ProvenSoft
 */
public class MainCsvWrite {

    public static void main(String[] args) {
        String pathToFile = "employee_ds.txt";
        //create test data.
        List<Employee> staff = initTestData();
        //instantiate persistence helper.
        EmployeeCsvFilePersist helper = new EmployeeCsvFilePersist();
        //set filename.
        helper.setFilename(pathToFile);
        //set delimiter.
        helper.setDelimiter("; ");
        //save data to file.
        int result = helper.save(staff);
        //show result to user.
        System.out.println("Number of employees saved: "+result);
    }

    private static List<Employee> initTestData() {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("111", "name111", 11));
        employees.add(new Employee("112", "name112", 12));
        employees.add(new Employee("113", "name113", 13));
        employees.add(new Employee("114", "name114", 14));
        employees.add(new Employee("115", "name115", 15));
        return employees;
    }
    
}

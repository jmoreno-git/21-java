package cat.proven.filepersistence;

import cat.proven.filepersistence.model.Employee;
import cat.proven.filepersistence.model.persist.EmployeeDataStreamFilePersist;
import java.util.List;
import cat.proven.utils.FilePersist;

/**
 *
 * @author ProvenSoft
 */
public class MainDataStreamRead {

    public static void main(String[] args) {
        String pathToFile = "employee_ds.txt";
        //instantiate persistence helper.
        FilePersist<Employee> helper = new EmployeeDataStreamFilePersist();
        //set filename.
        helper.setFilename(pathToFile);
        //read data from file.
        List<Employee> staff = helper.load();
        //show data to user.
        printEmployeeList(staff);
    }

    private static void printEmployeeList(List<Employee> data) {
        if (data != null) {
            data.forEach(e -> System.out.println(e.toString()));
        }
    }
    
}

package cat.proven.filepersistence;

import cat.proven.filepersistence.model.Employee;
import cat.proven.filepersistence.model.persist.EmployeeCsvFilePersist;
import cat.proven.utils.FilePersist;
import java.util.List;

/**
 *
 * @author ProvenSoft
 */
public class MainCsvRead {

    public static void main(String[] args) {
        String pathToFile = "employee_ds.txt";
        //instantiate persistence helper.
        EmployeeCsvFilePersist helper = new EmployeeCsvFilePersist();
        //set filename.
        helper.setFilename(pathToFile);
        //set delimiter.
        helper.setDelimiter("; ");        
        //read data from file.
        List<Employee> staff = helper.load();
        //show data to user.
        printEmployeeList(staff);
    }

    private static void printEmployeeList(List<Employee> data) {
        if (data != null) {
            data.forEach(e -> System.out.println(e.toString()));
        }
    }
    
}

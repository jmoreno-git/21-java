
package cat.proven.store;

import cat.proven.store.model.Product;
import cat.proven.store.model.Store;
import cat.proven.store.model.Tv;
import cat.proven.utils.test.ClassTester;
import exceptions.DuplicateProductException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ProvenSoft
 */
public class StoreTester extends ClassTester<Store> {
    public static void main(String[] args) {
        ClassTester<Store> ap = new StoreTester();
        ap.loadTests();
        ap.runTests();
    }
    
    @Override
    public void beforeAll() {
        super.beforeAll(); 
        instance = new Store();
    }    
    
    @Override
    public void afterAll() {
        super.afterAll(); 
        instance = null;
    }    

    @Override
    public void beforeEach() {
        super.beforeEach();
    }
    
    @Override
    public void afterEach() {
        super.afterEach();
    }

    @Override
    public void setUpData() {
        try {
            super.setUpData();
            instance.addProduct(new Product("C01", "D01", 101.0, 11));
            instance.addProduct(new Tv("C02", "D02", 102.0, 12, 54));
            instance.addProduct(new Product("C03", "D03", 103.0, 13));
            instance.addProduct(new Product("C04", "D04", 104.0, 14));
        } catch (DuplicateProductException ex) {
            Logger.getLogger(StoreTester.class.getName()).log(Level.SEVERE, null, ex);
        }
    } 
    
    @Override
    public void eraseData() {
        super.eraseData();
        instance.deleteAll();
    }
        
    @Override
    public void loadTests() {
        super.loadTests(); 
        tests.add( 
            new TestCase(
                "Add product Ok", 
                "addProduct", 
                packParameters(new Product("C09", "D09", 109.0, 19)), 
                ReturnCode.OK.getValue() 
            ) 
        );
        tests.add( 
             new TestCase(
                "Add product null", 
                "addProduct", 
                packParameters(new Object [1]), 
                ReturnCode.NULL_OBJ.getValue()
             ) 
        );
        tests.add( 
            new TestCase(
                "Add product code exists", 
                "addProduct", 
                packParameters(new Product("C02")), 
                ReturnCode.DUPL_ID.getValue()
            ) 
        );
        tests.add( 
            new TestCase(
                "Modify product code exists", 
                "modifyProduct", 
                packParameters(new Product("C03"), new Product("C13", "D13", 113.0, 13)), 
                ReturnCode.OK.getValue()
            ) 
        );
        tests.add( 
            new TestCase(
                "Remove product code exists", 
                "removeProduct", 
                packParameters(new Product("C03")), 
                ReturnCode.OK.getValue()
            ) 
        );
        tests.add( 
            new TestCase(
                "Find products with low stock", 
                "findProductsWithLowStock", 
                packParameters(13), 
                Arrays.asList(new Product("C01", "D01", 101.0, 11), new Tv("C02", "D02", 102.0, 12, 54))
            ) 
        );
    }
    
    // add tests here.


    /**
     * enumeration of return code values when testing.
     * @author Jose
     */
    enum ReturnCode { 

        OK(1),
        NULL_OBJ(-1),
        DUPL_ID(-2),
        OBJECT(-3);  //add here more codes and values.

        int value;

        ReturnCode(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }

    }
    
}

package cat.proven.store.utils;

/**
 *
 * @author ProvenSoft
 */
public enum ResultCode {
    /**
     * result codes: code and value.
     */
    OK  (1),
    NULL_OBJECT (-1),
    NOT_FOUND (-2),
    PK_DUPLICATE (-3);
 
    private final int code;
 
    ResultCode(int code) {
        this.code = code;
    }
 
    public int code() { return code; }
}


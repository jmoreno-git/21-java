package cat.proven.store.model;

import cat.proven.store.utils.ResultCode;
import exceptions.DuplicateProductException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ProvenSoft
 */
public class Store {
    
    private final List<Product> products;

    public Store() {
        products = new ArrayList<>();
    }    
    
    /**
     * searches a product in the data store
     * @param product the product to search
     * @return the product found or null if not found
     */
    public Product find(Product product) {
        Product result = null;
        int index = products.indexOf(product);
        if (index >= 0) {
            result = products.get(index);
        }
        return result;
    }
    
    /**
     * searches all products in data store
     * @return list of all products 
     */
    public List<Product> findAllProducts() {
        List<Product> result = new ArrayList<>(products);
        return result;
    }
    
    /**
     * searches products with stock lower than the given one
     * @param threshold the stock threshold to select products
     * @return list of products according to filter
     */
    public List<Product> findProductsWithLowStock(int threshold) {
        List<Product> result = new ArrayList<>();
        for (Product p : products) {
            if (p.getStock() < threshold) {
                result.add(p);
            }
        }
        return result;
    }
    
    /**
     * adds a product to data store, avoiding duplicates and null products
     * @param product the product to add
     * @return 1 if successfully added, a result code otherwise
     * @throws exceptions.DuplicateProductException if product code is already owned by a product in data store
     */
    public int addProduct(Product product) throws DuplicateProductException {
        int result = 0;
        if (product == null) {  //check nullity
            result = ResultCode.NULL_OBJECT.code();
        } else {  //check product existence
            if (products.contains(product)) {
                throw new DuplicateProductException(
                    String.format("Code %s already exists!", product.getCode())
                );
            } else {
                products.add(product);
                result = ResultCode.OK.code();
            }
        }
        return result;
    }

    /**
     * modifies a product in the data store
     * @param current current product
     * @param update updated product
     * @return 1 if successfully added, a result code otherwise
     */
    public int modifyProduct(Product current, Product update) {
        int result = 0;
        if ( (current == null) || (update == null) ) {
            result = ResultCode.NULL_OBJECT.code();
        } else {
            int index = products.indexOf(current);
            if (index < 0) {
                result = ResultCode.NOT_FOUND.code();
            } else {
                products.set(index, update);
                result = ResultCode.OK.code();
            }            
        }
        return result;        
    }
    
    /**
     * removes a product from the data store
     * @param product the product to remove
     * @return 1 if successfully added, a result code otherwise
     */
    public int removeProduct(Product product) {
        int result = 0;
        boolean b = products.remove(product);
        result = b ? 1 : 0;
        return result;         
    }
    
    /**
     * gets the type of the given object
     * @param obj the object whose type is to be obtained
     * @return the name of the type (SimpleClassName)
     */
    public String getProductType(Object obj) {
        String className = obj.getClass().getSimpleName();
        return className;
    }

    public void deleteAll() {
        products.removeAll(products);
    }
    
}

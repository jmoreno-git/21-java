package cat.proven.store;

import cat.proven.store.model.Product;
import cat.proven.store.model.Store;
import cat.proven.store.model.Tv;
import exceptions.DuplicateProductException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ProvenSoft
 */
public class Main {

    private Store myStore;

    public static void main(String[] args) {
        Main ap = new Main();
        ap.run();
    }

    private void run() {
        myStore = new Store();
        int counter = 0;
        try {
            System.out.println("===Adding test products===");
            counter += myStore.addProduct(new Product("C01", "D01", 101.0, 11));
            counter += myStore.addProduct(new Tv("C02", "D02", 102.0, 12, 54));
            counter += myStore.addProduct(new Product("C03", "D03", 103.0, 13));
            counter += myStore.addProduct(new Product("C04", "D04", 104.0, 14));
        } catch (DuplicateProductException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Number of products added: " + counter);
        System.out.println("===All products===");
        displayProductTable(myStore.findAllProducts());
        System.out.println("===Products with stock lower than 13===");
        displayProductTable(myStore.findProductsWithLowStock(13));
        System.out.println("===Modifying product with code C03===");
        myStore.modifyProduct(new Product("C03"), new Product("C13", "D13", 113, 23));
        displayProductTable(myStore.findAllProducts());
        System.out.println("===Removing product with code C03===");
        myStore.removeProduct(new Product("C13"));
        displayProductTable(myStore.findAllProducts());
        System.out.println("===Adding a product with existent code===");
        try {
            myStore.addProduct(new Product("C04"));  //throw an exception
        } catch (DuplicateProductException ex) {
            //Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Product not added and exception caught");
        }
    }

    private void displayProductTable(List<Product> list) {
        for (Product p : list) {
            System.out.println(p.toString());
        }
        System.out.println("Number of elements:" + list.size());
    }

}

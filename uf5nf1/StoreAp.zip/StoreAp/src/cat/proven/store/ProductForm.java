package cat.proven.store;

import cat.proven.store.model.Product;
import cat.proven.store.model.Tv;

/**
 *
 * @author ProvenSoft
 */
public final class ProductForm {

    public static Product input(String type) {
        Product p = switch (type) {
            case "Product" ->
                inputProduct();
            case "Tv" ->
                inputTv();
            default ->
                null;
        };
        return p;
    }

    public static Product inputProduct() {
        //TODO
        System.out.println("Reading a product...");
        return new Product("P999", "D999", 99.0, 9);
    }

    public static Product inputTv() {
        //TODO
        System.out.println("Reading a tv...");
        return new Tv("T999", "D999", 99.0, 9, 59);
    }
}

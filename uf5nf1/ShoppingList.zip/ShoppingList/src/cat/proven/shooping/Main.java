package cat.proven.shooping;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author jose
 */
public class Main {

    private List<String> articlesToBuy;
    private List<String> boughtArticles;
    private double amount;
    private boolean exit;
    private List<String> menu;
    
    public Main() {
        this.articlesToBuy = new ArrayList<>();
        this.boughtArticles = new ArrayList<>();
        this.amount = 0.0;
        menu = new ArrayList<>();
        generateMenu();
    }    
    
    public static void main(String[] args) {
        Main app = new Main();
        app.run();
    }

    private void run() {
        exit = false;
        do {
            int choice = displayMenu();
            switch (choice) {
                case 0 -> exitApp();
                case 1 -> displayArticlesToBuy();
                case 2 -> displayBoughtArticles();
                case 3 -> addToList();
                default -> {}
            }
        } while (!exit);
    }

    private int displayMenu() {
        System.out.println("Shopping list menu");
        for (int i=0; i<menu.size(); i++) {
            System.out.format("%d. %s\n", i, menu.get(i));
        }
        System.out.print("Input option:");
        Scanner sc = new Scanner(System.in);
        int option;
        try {
            option = sc.nextInt();
        } catch (InputMismatchException e) {
            option = -1;
        }
        return option;
    }

    private void generateMenu() {
        menu.add("Exit");
        menu.add("Show articles to buy");
        menu.add("Show bought articles");
        menu.add("Add to list");
        menu.add("Buy");
        menu.add("Remove from list");
    }

    private void exitApp() {
        this.exit = true;
    }

    private void displayArticlesToBuy() {
        displayList(articlesToBuy);
    }

    private void displayBoughtArticles() {
        displayList(boughtArticles);
    }

    private void addToList() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void displayList(List<String> list) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    
}

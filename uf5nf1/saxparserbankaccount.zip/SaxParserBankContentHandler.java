
import java.util.ArrayList;
import java.util.List;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author ProvenSoft
 */
public class SaxParserBankContentHandler extends DefaultHandler {

    private Account acct;
    private String temp;
    private List<Account> accList;
    
    public SaxParserBankContentHandler() {
        
    }

    /*
        * When the parser encounters plain text (not XML elements),
        * it calls(this method, which accumulates them in a string buffer
     */
    public void characters(char[] buffer, int start, int length) {
        temp = new String(buffer, start, length);
    }


    /*
        * Every time the parser encounters the beginning of a new element,
        * it calls this method, which resets the string buffer
     */
    public void startElement(String uri, String localName,
            String qName, Attributes attributes) throws SAXException {
        temp = "";
        switch (qName) {
            case "bank":
                accList = new ArrayList<>();
                break;
            case "account": 
                acct = new Account();
                acct.setType(attributes.getValue("type"));
                break;
        }
    }

    /*
        * When the parser encounters the end of an element, it calls this method
     */
    public void endElement(String uri, String localName, String qName)
            throws SAXException {

        switch (qName) {
            case "account":
                // add it to the list
                accList.add(acct);
                break;
            case "name":
                acct.setName(temp);
                break;
            case "id":
                acct.setId(Integer.parseInt(temp));
                break;
            case "amt":
                acct.setAmt(Double.parseDouble(temp));
                break;
        }
    }

    public List<Account> getData() {
        return accList;
    }
}

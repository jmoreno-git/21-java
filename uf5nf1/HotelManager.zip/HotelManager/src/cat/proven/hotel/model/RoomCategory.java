package cat.proven.hotel.model;

/**
 *
 * @author ProvenSoft
 */
public enum RoomCategory {
    STANDARD, SUITE
}

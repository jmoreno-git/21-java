package cat.proven.hotel.model;

import java.util.Objects;

/**
 *
 * @author ProvenSoft
 */
public class Customer {
    private String nif;
    private String name;

    public Customer(String nif, String name) {
        this.nif = nif;
        this.name = name;
    }

    public Customer(String nif) {
        this.nif = nif;
    }

    public String getNif() {
        return nif;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.nif);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Customer other = (Customer) obj;
        if (!Objects.equals(this.nif, other.nif)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Customer{nif=").append(nif);
        sb.append(", name=").append(name);
        sb.append('}');
        return sb.toString();
    }

}

package cat.proven.hotel.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Model for a Hotel management
 * @author ProvenSoft
 */
public class Hotel {

    private String name;
    private Map<Room, List<Customer>> occupancy;

    public Hotel(String name) {
        this.name = name;
        this.occupancy = new HashMap<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<Room, List<Customer>> getOccupancy() {
        return occupancy;
    }

    public void setOccupancy(Map<Room, List<Customer>> occupancy) {
        this.occupancy = occupancy;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 53 * hash + Objects.hashCode(this.name);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Hotel other = (Hotel) obj;
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Hotel{name=").append(name);
        sb.append(", occupancy=").append(occupancy);
        sb.append('}');
        return sb.toString();
    }

    public Room findRoom(Room room) {
//        return occupancy
//                .keySet()
//                .stream()
//                .filter(x -> x.equals(room))
//                .findFirst()
//                .get();
        Room result = null;
        List<Room> allRooms = findAllRooms();
        int index = allRooms.indexOf(room);
        if (index >= 0) {
            result = allRooms.get(index);
        }
        return result;
    }

    public List<Room> findAllRooms() {
        return occupancy
                .keySet()
                .stream()
                .collect(Collectors.toList());
    }

    public List<Customer> findAllCustomers() {
        List<Customer> result = new ArrayList<>();
        return occupancy
                .values()
                .stream()
                .flatMap(List::stream)
                .collect(Collectors.toList());
    }

    public List<Customer> findCustomersByRoom(Room room) {
        return occupancy.get(room);
    }

    public List<Room> findAllFreeRooms() {
        List<Room> result = new ArrayList<>();
        Set<Map.Entry<Room, List<Customer>>> entries = occupancy.entrySet();
        for (Map.Entry<Room, List<Customer>> e: entries) {
            if (e.getValue().size() == 0) {
                result.add(e.getKey());
            }
        }
        return result;
    }

    public List<Room> findFreeRoomsByCategoryAndPlaces(RoomCategory category, int places) {
        List<Room> result = new ArrayList<>();
        List<Room> allRooms = findAllRooms();
        for (Room o: allRooms) {
            if (o.getCategory().equals(category) && o.getPlaces()==places) {
                result.add(o);
            }
        }
        return result;
    }

    public int checkIn(Room room, List<Customer> customers) {
        int result = 0;
        if (occupancy.containsKey(room)) {
            result = (occupancy.get(room).addAll(customers)) ? 1 : 0;
        }
        return result;
    }

    public int checkOut(Room room) {
        int result = 0;
        if (occupancy.containsKey(room)) {
            occupancy.get(room).clear();
            result = 1;
        }
        return result;
    }

    public void generateTestData() {
        Room r;
        Customer c;
        List<Customer> custs;

        for (int i = 100; i < 110; i++) {
            r = new Room(i);
            custs = new ArrayList<>();
            for (int j = 0; j < 2; j++) {
                c = new Customer("nif" + String.valueOf(i * 10 + j), "name" + String.valueOf(i * 10 + j));
                custs.add(c);
                //System.out.println(String.valueOf(i*10+j));
            }
            occupancy.put(r, custs);
        }
    }
    
    public int addRoom(Room room) {
        return (occupancy.putIfAbsent(room, new ArrayList<>())==null) ? 1 : 0;
    }
    
    public int removeRoom(Room room) {
        //TODO avoid removing room with customers
        return (occupancy.remove(room) == null) ? 0 : 1;
    }
    
    public int modifyRoom(Room room) {
        //TODO perform security checks
        return (occupancy.replace(room, occupancy.get(room))==null) ? 0 : 1;
    }
    
}

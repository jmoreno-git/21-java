package cat.proven.hotel;

import cat.proven.hotel.model.Hotel;

/**
 *
 * @author ProvenSoft
 */
public class Main {
    
    private Hotel myHotel;

    public static void main(String[] args) {
        Main ap = new Main();
        ap.run();
    }
    
    public void run() {
        myHotel = new Hotel("The Best Exotic Marigold Hotel");
        myHotel.generateTestData();
        System.out.println(myHotel.findAllRooms());
        System.out.println(myHotel.findAllCustomers());
    }
}

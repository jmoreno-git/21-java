package cat.proven.shoppinglist;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Main {
    
    //attributes
    private List<String> articlesToBuy;
    private List<String> boughtArticles;
    private double totalAmount;
    
    private boolean exit;  //flag to exit application.
    private List<String> menu;  //the menu of the application.

    public Main() {
        this.articlesToBuy = new ArrayList<>();
        this.boughtArticles = new ArrayList<>();
        this.totalAmount = 0.0;
        this.menu = new ArrayList<>();
    }
    
    public static void main(String[] args) {
        Main ap = new Main();
        ap.run();
    }
    
    private void run() {
       generateMenu();
       exit = false;
       generateTestData();  //fake data to test the application. Remove for production.
       do {
            //display menu and get user's choice.
            System.out.println("Shopping list menu");
            int choice = displaySelector(menu);
            //process choice.
            switch (choice) {  //new switch: returns a value.
                case 0 -> exitApp();  //break clause not required.
                case 1 -> displayArticlesToBuy();
                case 2 -> displayBoughtArticles();
                case 3 -> addToList();
                case 4 -> buy();
                case 5 -> removeFromList();
                default -> System.out.println("Bad option");
            }
            //System.out.println("Executing option: " + choice);
       } while (!exit);
        
    }
    
    /**
     * displays a selector with a list of options and gets option number from user.
     * @return the number of the option selected by user or -1 in case of error.
     */
    private int displaySelector(List<String> options) {
        for (int i=0; i<options.size();i++) {
            System.out.format("%d. %s\n", i, options.get(i));
        }
        System.out.print("Enter your choice: ");
        Scanner sc = new Scanner(System.in);
        int option;
        try {
            option = sc.nextInt();
        } catch (InputMismatchException e) {
            option = -1;
        }
        return option;
    }

    private void generateMenu() {
        menu.add("Exit");
        menu.add("Show articles to buy");
        menu.add("Show bought articles");
        menu.add("Add to list");
        menu.add("Buy");
        menu.add("Remove from list");
    }

    /**
     * exits application.
     */
    private void exitApp() {
        exit = true;
    }

    /**
     * displays the list of articles to buy
     */
    private void displayArticlesToBuy() {
        displayList(articlesToBuy);
    }

    /**
     * displays the list of bought articles
     */
    private void displayBoughtArticles() {
        displayList(boughtArticles);
        System.out.println("Total amount: " +  totalAmount);
    }

    /**
     * asks the user to input the article to add, 
     * verifies that the article does not exist in any list
     * and adds it to list,
     * and reports result to user
     */
    private void addToList() {
        //read article form user
        String article = inputString("Input article: ");
        if (article != null) {
            if (articlesToBuy.contains(article) 
                    || boughtArticles.contains(article)) {
                System.out.println("Article is already in the list");
            } else {
                articlesToBuy.add(article);
                System.out.println("Article successfully added");
            }
        } else {
            System.out.println("Error reading article");
        }
    }

    /**
     * displays the list of articles to buy,
     * asks the user to select an article.
     * I correctly selected, 
     * searches the article in the list of articles to buy,
     * asks the user to input the price,
     * moves an article from the list of articles to buy 
     * to the list of bought articles and reports result to user.
     * If not, reports error to user.
     */
    private void buy() {
        //display list of articles to buy and read article from user
        int articleSelected = displaySelector(articlesToBuy);       
        //validate user's choice
        //System.out.println("DEBUG: SELECTED ARTICLE: "+articleSelected);
        if ((articleSelected>=0) && (articleSelected<articlesToBuy.size())) {
            //read price from user
            String sprice = inputString("Enter price: ");
            try {
                double price = Double.parseDouble(sprice);
                if (price >= 0)  {
                    //remove article from articles to buy
                    String article = articlesToBuy.get(articleSelected);
                    articlesToBuy.remove(articleSelected);
                    //add article to bought articles
                    boughtArticles.add(article);
                    //update total amount
                    this.totalAmount += price;
                    //report result to user 
                    System.out.println("Article successfully bought");
                    System.out.println("Total amount: "+totalAmount);
                } else {
                    System.out.println("Price should not be negative");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error reading price");
            }       
        } else {
            System.out.println("Article not found!");
        }
    }

    /**
     * asks the user to input the text of the article to remove,
     * searches the article in the list and, if found, shows the article
     * and asks for confirmation. If not found, reports error to user.
     * Then removes the article from the list of articles to buy,
     * and reports result to user
     */
    private void removeFromList() {
        //read article from user
        String article = inputString("Enter article to remove: ");
        //validate input
        if (articlesToBuy.contains(article)) {
            //ask for confirmation
            System.out.println("You are about to remove article: "+article);
            if (confirm("Are you sure? ")) {
                articlesToBuy.remove(article);
                System.out.println("Article successfully removed");
            } else {
                System.out.println("Operation cancelled by user");
            }
        } else {
            System.out.println("Article not found");
        }
    }
    
    /**
     * displays list to user
     * @param list the list to display
     */
    private void displayList(List<String> list) {
        for (String elem: list) {
            System.out.println(elem);
        }
        System.out.format("Number of elements: %d\n", list.size());
        
    }
    
    /**
     * initializes test data
     */
    private void generateTestData() {
        //generate data in articlesToBuy.
        articlesToBuy.add("Milk");
        articlesToBuy.add("Bread");
        articlesToBuy.add("Chicken");
        articlesToBuy.add("Sushi");
        articlesToBuy.add("Mineral water");
        articlesToBuy.add("Apples");
        articlesToBuy.add("Watermelon");      
        //generate data in boughtArticles.
        boughtArticles.add("Meat");
        boughtArticles.add("Tomatoes");
        boughtArticles.add("Potatoes");
        //initialize total amount.
        totalAmount = 30.0;
    }

    /**
     * prompts a message to user and reads a text from user
     * @return the text been read
     */
    private String inputString(String message) {
        System.out.print(message);               
        Scanner sc = new Scanner(System.in);
        return sc.next();
    }
    
    /**
     * prompts a message to user and ask for confirmation
     * @param message the message to show to user
     * @return true or false
     */
    private boolean confirm(String message) {
        boolean b = false;
        System.out.print(message);
        Scanner sc = new Scanner(System.in);
        try {
            b = sc.nextBoolean();
        } catch (InputMismatchException e) {
            b = false;
        }
        return b;
    }
    
}

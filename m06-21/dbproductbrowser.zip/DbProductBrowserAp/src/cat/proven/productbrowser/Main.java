package cat.proven.productbrowser;

import cat.proven.productbrowser.views.ProductBrowserFrame;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 *
 * @author ProvenSoft
 */
public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new ProductBrowserFrame();
            frame.setVisible(true);
        });
    }

}

package cat.proven.productbrowser.views;

import javax.swing.JOptionPane;

/**
 *
 * @author ProvenSoft
 */
public class ProductBrowserFrame extends javax.swing.JFrame {

    public ProductBrowserFrame() {
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        productBrowserPanel = new cat.proven.productbrowser.views.ProductBrowserPanel();
        mnuBar = new javax.swing.JMenuBar();
        mnuFile = new javax.swing.JMenu();
        itemExit = new javax.swing.JMenuItem();
        mnuEdit = new javax.swing.JMenu();
        itemConn = new javax.swing.JMenuItem();
        itemDisconn = new javax.swing.JMenuItem();
        mnuHelp = new javax.swing.JMenu();
        itemAbout = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Product browsing form");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        mnuFile.setText("File");

        itemExit.setText("Exit");
        itemExit.setActionCommand("exit");
        itemExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemExitActionPerformed(evt);
            }
        });
        mnuFile.add(itemExit);

        mnuBar.add(mnuFile);

        mnuEdit.setText("Edit");

        itemConn.setText("Connect");
        itemConn.setActionCommand("connect");
        itemConn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemConnActionPerformed(evt);
            }
        });
        mnuEdit.add(itemConn);

        itemDisconn.setText("Disconnect");
        itemDisconn.setActionCommand("disconnect");
        itemDisconn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemDisconnActionPerformed(evt);
            }
        });
        mnuEdit.add(itemDisconn);

        mnuBar.add(mnuEdit);

        mnuHelp.setText("Help");

        itemAbout.setText("About");
        itemAbout.setActionCommand("about");
        itemAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemAboutActionPerformed(evt);
            }
        });
        mnuHelp.add(itemAbout);

        mnuBar.add(mnuHelp);

        setJMenuBar(mnuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(productBrowserPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(productBrowserPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 12, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void itemExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemExitActionPerformed
        exitApp();
    }//GEN-LAST:event_itemExitActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        exitApp();
    }//GEN-LAST:event_formWindowClosing

    private void itemAboutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemAboutActionPerformed
        JOptionPane.showMessageDialog(this, "Product browser by ProvenSoft");
    }//GEN-LAST:event_itemAboutActionPerformed

    private void itemConnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemConnActionPerformed
        productBrowserPanel.connectToDatabase();
    }//GEN-LAST:event_itemConnActionPerformed

    private void itemDisconnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemDisconnActionPerformed
        productBrowserPanel.disconnectFromDatase();
    }//GEN-LAST:event_itemDisconnActionPerformed

    /**
     * asks for confirmation and exits application
     */
    private void exitApp() {
        int answer = JOptionPane.showConfirmDialog(this, "Sure to exit?");
        if (answer == JOptionPane.YES_OPTION) {
            this.dispose();
            System.exit(0);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem itemAbout;
    private javax.swing.JMenuItem itemConn;
    private javax.swing.JMenuItem itemDisconn;
    private javax.swing.JMenuItem itemExit;
    private javax.swing.JMenuBar mnuBar;
    private javax.swing.JMenu mnuEdit;
    private javax.swing.JMenu mnuFile;
    private javax.swing.JMenu mnuHelp;
    private cat.proven.productbrowser.views.ProductBrowserPanel productBrowserPanel;
    // End of variables declaration//GEN-END:variables

}

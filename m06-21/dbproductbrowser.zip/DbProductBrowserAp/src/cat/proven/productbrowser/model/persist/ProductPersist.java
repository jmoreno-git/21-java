package cat.proven.productbrowser.model.persist;

import cat.proven.productbrowser.model.Product;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Browsing resultset of product
 *
 * @author ProvenSoft
 */
public class ProductPersist {

    private Connection connection;
    private ResultSet resultSet;
    private final String QUERY = "select * from products";

    public ProductPersist() {
//        try {
//            connect();
//            executeQuery();
//        } catch (SQLException ex) {
//            Logger.getLogger(ProductPersist.class.getName()).log(Level.SEVERE, null, ex);
//        }
    }

    /**
     * gets connection to database
     *
     * @throws SQLException in case of error
     */
    public void connect() throws SQLException {
        this.connection = (new DbConnect().getConnection());
    }

    /**
     * executes query to populate resultset
     *
     * @throws SQLException iin case of error
     */
    public void executeQuery() throws SQLException {
        Statement st = connection.createStatement(
                ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
        resultSet = st.executeQuery(QUERY);
    }

    /**
     * disconnects from database
     *
     * @throws SQLException in case of error
     */
    public void disconnect() throws SQLException {
        resultSet.close();
        resultSet = null;
        connection.close();
        connection = null;
    }

    /**
     * moves resultset cursor to first position
     *
     * @return true if successful, false otherwise
     */
    public boolean goFirst() {
        boolean success = false;
        if (resultSet != null) {
            try {
                success = resultSet.first();
            } catch (SQLException ex) {
                //Logger.getLogger(ProductPersist.class.getName()).log(Level.SEVERE, null, ex);
                success = false;
            }
        }
        return success;
    }

    /**
     * moves resultset cursor to last position
     *
     * @return true if successful, false otherwise
     */
    public boolean goLast() {
        boolean success = false;
        if (resultSet != null) {
            try {
                success = resultSet.last();
            } catch (SQLException ex) {
                //Logger.getLogger(ProductPersist.class.getName()).log(Level.SEVERE, null, ex);
                success = false;
            }
        }
        return success;
    }

    /**
     * moves resultset cursor to next position
     *
     * @return true if successful, false otherwise
     */
    public boolean goNext() {
        boolean success = false;
        if (resultSet != null) {
            try {
                if (!resultSet.isLast()) {
                    success = resultSet.next();
                }
            } catch (SQLException ex) {
                //Logger.getLogger(ProductPersist.class.getName()).log(Level.SEVERE, null, ex);
                success = false;
            }
        }
        return success;
    }

    /**
     * moves resultset cursor to previous position
     *
     * @return true if successful, false otherwise
     */
    public boolean goPrevious() {
        boolean success = false;
        if (resultSet != null) {
            try {
                if (!resultSet.isFirst()) {
                    success = resultSet.previous();
                }
            } catch (SQLException ex) {
                //Logger.getLogger(ProductPersist.class.getName()).log(Level.SEVERE, null, ex);
                success = false;
            }
        }
        return success;
    }

    /**
     * inserts a product
     *
     * @param product the product to insert
     * @return true if successful, false otherwise
     */
    public boolean insert(Product product) {
        boolean success = false;
        if (resultSet != null) {
            try {
                resultSet.moveToInsertRow();
                resultSet.updateString("code", product.getCode());
                resultSet.updateString("description", product.getDescription());
                resultSet.updateDouble("price", product.getPrice());
                resultSet.updateInt("stock", product.getStock());
                resultSet.insertRow();
//                resultSet.moveToCurrentRow();
                resultSet.last();
                resultSet.refreshRow();
                success = true;
            } catch (SQLException ex) {
                //Logger.getLogger(ProductPersist.class.getName()).log(Level.SEVERE, null, ex);
                success = false;
            }
        }
        return success;
    }

    /**
     * updates product at current cursor position
     *
     * @param product the product with new values
     * @return true if successful, false otherwise
     */
    public boolean update(Product product) {
        boolean success = false;
        if (resultSet != null) {
            try {
                resultSet.updateString("code", product.getCode());
                resultSet.updateString("description", product.getDescription());
                resultSet.updateDouble("price", product.getPrice());
                resultSet.updateInt("stock", product.getStock());
                resultSet.updateRow();
                success = true;
            } catch (SQLException ex) {
                //Logger.getLogger(ProductPersist.class.getName()).log(Level.SEVERE, null, ex);
                success = false;
            }
        }
        return success;
    }

    /**
     * deletes product at current cursor position
     *
     * @return true if successful, false otherwise
     */
    public boolean delete() {
        boolean success = false;
        if (resultSet != null) {
            try {
                resultSet.deleteRow();
                //if (!resultSet.isLast()) resultSet.next();
                success = true;
            } catch (SQLException ex) {
                //Logger.getLogger(ProductPersist.class.getName()).log(Level.SEVERE, null, ex);
                success = false;
            }
        }
        return success;
    }

    /**
     * gets products at current cursor position
     *
     * @return product object or null in case of error
     */
    public Product getCurrent() {
        Product product = null;
        if (resultSet != null) {
            try {
                long id = resultSet.getLong("id");
                String code = resultSet.getString("code");
                String description = resultSet.getString("description");
                double price = resultSet.getDouble("price");
                int stock = resultSet.getInt("stock");
                product = new Product(id, code, description, price, stock);
            } catch (SQLException ex) {
                //Logger.getLogger(ProductPersist.class.getName()).log(Level.SEVERE, null, ex);
                product = null;
            }
        }
        return product;
    }

}

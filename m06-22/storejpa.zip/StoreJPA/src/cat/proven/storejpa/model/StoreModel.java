package cat.proven.storejpa.model;

import cat.proven.storejpa.controllers.exceptions.NonexistentEntityException;
import cat.proven.storejpa.controllers.exceptions.PreexistingEntityException;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Parameter;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * @author ProvenSoft
 */
public class StoreModel {

    EntityManagerFactory emFactory;

    public StoreModel() {
        emFactory = Persistence.createEntityManagerFactory("StoreJPAPU");
    }

    public EntityManager getEntityManager() {
        return emFactory.createEntityManager();
    }

    /**
     * ======= Category related methods ======
     */
    public int addCategory(Category category) throws PreexistingEntityException {
        int result = 0;
        if (category.getProducts() == null) {
            category.setProducts(new ArrayList<Product>());
        }
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            //get attached products
            List<Product> attachedProducts = new ArrayList<Product>();
            for (Product p : category.getProducts()) {
                p = em.getReference(p.getClass(), p.getId());
                attachedProducts.add(p);
            }
            category.setProducts(attachedProducts);
            //persist
            em.persist(category);
            em.getTransaction().commit();
            result = 1;
        } catch (Exception ex) {
            if (searchCategoryByCode(category.getCode()) != null) {
                throw new PreexistingEntityException("Category " + category + " already exists.");
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return result;
    }

    public int modifyCategory(Category category) throws NonexistentEntityException {
        int result = 0;
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Category persistentCategory = em.find(Category.class, category.getCode());
            if (persistentCategory != null) {
                em.detach(persistentCategory);
                persistentCategory = new Category(category);
                em.merge(persistentCategory);
                em.getTransaction().commit();
                result = 1;
            } else {
                throw new NonexistentEntityException("Category with code " + category.getCode() + " does not exist.");
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return result;
    }

    public int removeCategory(Category category) throws NonexistentEntityException {
        int result = 0;
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            String code = category.getCode();
            try {
                category = em.getReference(Category.class, category.getCode());
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("Category with code " + category.getCode() + " does not exist.");
            }
            em.remove(category);
            em.getTransaction().commit();
            result = 1;
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return result;
    }

    public Category searchCategoryByCode(String code) {
        EntityManager em = getEntityManager();
        Category category = null;
        try {
            category = em.find(Category.class, code);  //returns null if not found.
        } finally {
            em.close();
        }
        return category;
    }

    public List<Category> searchAllCategories() {
        EntityManager em = getEntityManager();
        List<Category> categories = null;
        try {
            Query query = em.createNamedQuery("Category.findAll");
            categories = query.getResultList();
        } finally {
            em.close();
        }
        return categories;
    }

    public void fetchCategoryProducts(Category c) {
        EntityManager em = getEntityManager();
        String sql = "SELECT p FROM Product p where p.category = :code";
        TypedQuery<Product> query2 = em.createQuery(sql, Product.class);
        query2.setParameter("code", c);
        List<Product> products = query2.getResultList();
        if (products != null) {
            for (Product p : products) {
                p = em.getReference(p.getClass(), p.getId());
            }
            c.setProducts(products);
        }
    }

    /**
     * ======= Product related methods ======
     */
    public int addProduct(Product product) throws PreexistingEntityException, EntityNotFoundException {
        int result = 0;
        if (product.getCategory() == null) {
            product.setCategory(new Category());
        }
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            //get attached category
            Category attachedCategory = product.getCategory();
            attachedCategory = em.getReference(attachedCategory.getClass(), attachedCategory.getCode());
            product.setCategory(attachedCategory);
            //persist
            em.persist(product);
            em.getTransaction().commit();
            result = 1;
        } catch (Exception ex) {
            if (searchProductById(product.getId()) != null) {
                throw new PreexistingEntityException("Product " + product + " already exists.");
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return result;
    }

    public Product searchProductById(Integer id) {
        EntityManager em = getEntityManager();
        Product product = null;
        try {
            product = em.find(Product.class, id);  //returns null if not found.
        } finally {
            em.close();
        }
        return product;
    }

    public List<Product> searchAllProducts() {
        EntityManager em = getEntityManager();
        List<Product> products = null;
        try {
            Query query = em.createNamedQuery("Product.findAll");
            products = query.getResultList();
        } finally {
            em.close();
        }
        return products;
    }

    public int removeProduct(Product product) throws NonexistentEntityException {
        int result = 0;
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Integer id = product.getId();
            try {
                product = em.getReference(product.getClass(), product.getId());
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("Product with id " + product.getId() + " does not exist.");
            }
            em.remove(product);
            em.getTransaction().commit();
            result = 1;
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return result;
    }

    public int modifyProduct(Product product) throws NonexistentEntityException {
        int result = 0;
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Product persistentProduct = em.find(Product.class, product.getId());
            if (persistentProduct != null) {
                em.detach(persistentProduct);
                persistentProduct = new Product(product);
                //get attached category
                Category attachedCategory = product.getCategory();
                attachedCategory = em.getReference(attachedCategory.getClass(), attachedCategory.getCode());
                product.setCategory(attachedCategory);
                em.merge(persistentProduct);
                em.getTransaction().commit();
                result = 1;
            } else {
                throw new NonexistentEntityException("Product with id " + product.getId() + " does not exist.");
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return result;
    }

}

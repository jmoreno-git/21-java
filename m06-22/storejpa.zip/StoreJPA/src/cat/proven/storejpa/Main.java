package cat.proven.storejpa;

import cat.proven.storejpa.controllers.exceptions.NonexistentEntityException;
import cat.proven.storejpa.controllers.exceptions.PreexistingEntityException;
import cat.proven.storejpa.model.Category;
import cat.proven.storejpa.model.Product;
import cat.proven.storejpa.model.StoreModel;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityNotFoundException;

/**
 *
 * @author ProvenSoft
 */
public class Main {

    private StoreModel model;
    private Scanner scan;

    public static void main(String[] args) {
        Main ap = new Main();
        ap.run();
    }

    private void run() {
        scan = new Scanner(System.in);
        model = new StoreModel();
        //*** Test categories
        //
        testSearchCategory();
        //
        testSearchAllCategories();
        //
        testAddCategory();
        //
        testSearchAllCategories();
        //
        testModifyCategory();
        //
        testSearchAllCategories();
        //
        testRemoveCategory();
        //
        testSearchAllCategories();
        //
        //*** Test products
        //
        testSearchProduct();
        //
        testSearchAllProducts();
        //
        testAddProduct();
        //
        testSearchAllProducts();
        //
        testModifyProduct();
        //
        testSearchAllProducts();
        //
        testRemoveProduct();
        //
        testSearchAllProducts();
    }

    public void showOne(Object obj) {
        if (obj != null) {
            System.out.println(obj.toString());
        } else {
            System.out.println("Null object");
        }
    }

    public void showList(List<?> lst) {
        if (lst != null) {
            lst.forEach(o -> {
                System.out.println(o.toString());
            });
            System.out.println("Number of elements: " + lst.size());
        } else {
            System.out.println("Null data");
        }
    }

    private String readString(String prompt) {
        System.out.print(prompt);
        return scan.next();
    }

    /**
     * ==== Tests related to Category
     */
    private void testSearchCategory() {
        System.out.println("===Test: Search category by code===");
        String code = readString("Input category code to search: ");
        Category category = model.searchCategoryByCode(code);
        if (category != null) {
            model.fetchCategoryProducts(category);
            showOne(category);
        } else {
            System.out.println("Code not found: " + code);
        }
    }

    private void testSearchAllCategories() {
        System.out.println("===Test: Search all categories===");
        List<Category> categories = model.searchAllCategories();
        categories.forEach(c -> {
            model.fetchCategoryProducts(c);
        });
        showList(categories);
    }

    private void testAddCategory() {
        System.out.println("===Test: Add category===");
        //read data
        String code = readString("Category code: ");
        String description = readString("Category description: ");
        Category categoryNew = new Category(code, description);
        //persist
        try {
            int result = model.addCategory(categoryNew);
            System.out.println("Result:" + result);
        } catch (PreexistingEntityException ex) {
            System.out.println(ex.getMessage());
        }
    }

    private void testRemoveCategory() {
        System.out.println("===Test: Remove category===");
        String code = readString("Input category code to remove: ");
        Category category = new Category(code);
        try {
            int result = model.removeCategory(category);
            System.out.println("Result:" + result);
        } catch (NonexistentEntityException ex) {
            System.out.println(ex.getMessage());
        }
    }

    private void testModifyCategory() {
        System.out.println("===Test: Modify category===");
        String code = readString("Input category code to modify: ");
        Category category = model.searchCategoryByCode(code);
        //read data
        String description = readString("Category description: ");
        Category categoryNew = new Category(code, description);
        try {
            //merge
            int result = model.modifyCategory(categoryNew);
            System.out.println("Result:" + result);
        } catch (NonexistentEntityException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * ====Tests related to Product
     */
    private void testSearchProduct() {
        System.out.println("===Test: Search product by id===");
        String sid = readString("Input product id to search: ");
        try {
            Integer id = Integer.parseInt(sid);
            Product product = model.searchProductById(id);
            if (product != null) {
                showOne(product);
            } else {
                System.out.println("Id not found: " + id);
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid data" + e.getMessage());
        }
    }

    private void testSearchAllProducts() {
        System.out.println("===Test: Search all products===");
        List<Product> products = model.searchAllProducts();
//        products.forEach(p -> {
//            model.fetchProductCategory(p);
//        });
        showList(products);
    }

    private void testAddProduct() {
        System.out.println("===Test: Add product===");
        //read data
//        String sid = readString("Product id: ");  //PK
        String code = readString("Product code: ");
        String description = readString("Product description: ");
        String sprice = readString("Product price: ");
        String catCode = readString("Product category code: ");
        try {
//            Integer id = Integer.parseInt(sid);   //PK
            Double price = Double.parseDouble(sprice);
            Product product = new Product(0, code, description, price);
            product.setCategory(new Category(catCode));
            //persist
            try {
                int result = model.addProduct(product);
                System.out.println("Result:" + result);
            } catch (PreexistingEntityException | EntityNotFoundException ex) {
                System.out.println(ex.getMessage());
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid data" + e.getMessage());
        }
    }

    private void testRemoveProduct() {
        System.out.println("===Test: Remove product===");
        String sid = readString("Input product id to remove: ");
        try {
            Integer id = Integer.parseInt(sid);
            Product product = new Product(id);
            try {
                int result = model.removeProduct(product);
                System.out.println("Result:" + result);
            } catch (NonexistentEntityException ex) {
                System.out.println(ex.getMessage());
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid data" + e.getMessage());
        }

    }

    private void testModifyProduct() {
        System.out.println("===Test: Modify product===");
        //read data
        String sid = readString("Product id: ");
        try {
            Integer id = Integer.parseInt(sid);
            Product product = model.searchProductById(id);
            String code = readString("Product code: ");
            String description = readString("Product description: ");
            String sprice = readString("Product price: ");
            String catCode = readString("Product category code: ");
            Double price = Double.parseDouble(sprice);
            Product productNew = new Product(id, code, description, price);
            productNew.setCategory(new Category(catCode));
            try {
                //merge
                int result = model.modifyProduct(productNew);
                System.out.println("Result:" + result);
            } catch (NonexistentEntityException | EntityNotFoundException ex) {
                System.out.println(ex.getMessage());
            } 
        } catch (NumberFormatException e) {
            System.out.println("Invalid data" + e.getMessage());
        }
    }

}
